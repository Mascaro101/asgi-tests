function roundToNearestTen(value) {
    return Math.round(value / 10) * 10;
};

(function() {
    const wheel = document.querySelector('.wheel');
    const startButton = document.querySelector('.button');

    let deg = 0;

    startButton.addEventListener('click', () => {
        startButton.style.pointerEvents = 'none';

        deg = Math.floor(5000 + Math.random() * 5000);

        wheel.style.transition = 'all 10s ease';

        wheel.style.transform = `rotate(${deg}deg)`;

        wheel.classList.add('blur');
    });

    wheel.addEventListener('transitionend', () => {
        wheel.classList.remove('blur');

        startButton.style.pointerEvents = 'auto';

        wheel.style.transition = 'none';

        const actualDeg = roundToNearestTen(deg % 360);

        console.log(actualDeg)

        wheel.style.transform = `rotate(${actualDeg}deg)`;

        const resultElement = document.getElementById('result');

        let resultText = '';
        let colorClass = '';

        if (actualDeg >= 10 && actualDeg < 20) {
            resultText = '26 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 20 && actualDeg < 30) {
            resultText = '3 RED';
            colorClass = 'red';
        } else if (actualDeg >= 30 && actualDeg < 40) {
            resultText = '35 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 40 && actualDeg < 50) {
            resultText = '12 RED';
            colorClass = 'red';
        } else if (actualDeg >= 50 && actualDeg < 60) {
            resultText = '28 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 60 && actualDeg < 70) {
            resultText = '7 RED';
            colorClass = 'red';
        } else if (actualDeg >= 70 && actualDeg < 80) {
            resultText = '29 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 80 && actualDeg < 90) {
            resultText = '18 RED';
            colorClass = 'red';
        } else if (actualDeg >= 90 && actualDeg < 100) {
            resultText = '22 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 100 && actualDeg < 110) {
            resultText = '9 RED';
            colorClass = 'red';
        } else if (actualDeg >= 110 && actualDeg < 120) {
            resultText = '31 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 120 && actualDeg < 130) {
            resultText = '14 RED';
            colorClass = 'red';
        } else if (actualDeg >= 130 && actualDeg < 140) {
            resultText = '20 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 140 && actualDeg < 150) {
            resultText = '1 RED';
            colorClass = 'red';
        } else if (actualDeg >= 150 && actualDeg < 160) {
            resultText = '33 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 160 && actualDeg < 170) {
            resultText = '16 RED';
            colorClass = 'red';
        } else if (actualDeg >= 170 && actualDeg < 180) {
            resultText = '24 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 180 && actualDeg < 190) {
            resultText = '5 RED';
            colorClass = 'red';
        } else if (actualDeg >= 190 && actualDeg < 200) {
            resultText = '10 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 200 && actualDeg < 210) {
            resultText = '23 RED';
            colorClass = 'red';
        } else if (actualDeg >= 210 && actualDeg < 220) {
            resultText = '8 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 220 && actualDeg < 230) {
            resultText = '30 RED';
            colorClass = 'red';
        } else if (actualDeg >= 230 && actualDeg < 240) {
            resultText = '11 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 240 && actualDeg < 250) {
            resultText = '36 RED';
            colorClass = 'red';
        } else if (actualDeg >= 250 && actualDeg < 260) {
            resultText = '13 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 260 && actualDeg < 270) {
            resultText = '27 RED';
            colorClass = 'red';
        } else if (actualDeg >= 270 && actualDeg < 280) {
            resultText = '6 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 280 && actualDeg < 290) {
            resultText = '34 RED';
            colorClass = 'red';
        } else if (actualDeg >= 290 && actualDeg < 300) {
            resultText = '17 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 300 && actualDeg < 310) {
            resultText = '25 RED';
            colorClass = 'red';
        } else if (actualDeg >= 310 && actualDeg < 320) {
            resultText = '2 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 320 && actualDeg < 330) {
            resultText = '21 RED';
            colorClass = 'red';
        } else if (actualDeg >= 330 && actualDeg < 340) {
            resultText = '4 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 340 && actualDeg < 350) {
            resultText = '19 RED';
            colorClass = 'red';
        } else if (actualDeg >= 350 && actualDeg < 360) {
            resultText = '15 BLACK';
            colorClass = 'black';
        } else if (actualDeg >= 360 && actualDeg < 370) {
            resultText = '32 RED';
            colorClass = 'red';
        } else {
            resultText = '0 GREEN';
            colorClass = 'green';
        }

        // Actualizar el elemento de resultado
        resultElement.textContent = resultText;
        resultElement.className = ''; // Eliminar todas las clases
        resultElement.classList.add(colorClass);
    });
})();
